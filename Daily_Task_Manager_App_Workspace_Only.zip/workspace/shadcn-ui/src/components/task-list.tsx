import { useState, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import { PlusIcon, BellIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TaskCard } from './task-card';
import { TaskForm } from './task-form';
import { Task, useTodoStore } from '@/lib/db';
import { toast } from 'sonner';

export const TaskList = () => {
  const { 
    tasks, 
    addTask, 
    updateTask, 
    reorderTasks,
    getTasksDueToday,
    getTasksDueSoon,
    resetRecurringTasks
  } = useTodoStore();
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [activeTab, setActiveTab] = useState('today');
  const [filteredTasks, setFilteredTasks] = useState<Task[]>([]);
  const [showCompleted, setShowCompleted] = useState(false);
  
  // Check for notifications permission
  const [notificationsPermission, setNotificationsPermission] = useState<NotificationPermission | null>(null);
  
  useEffect(() => {
    // Check if notifications are supported
    if ('Notification' in window) {
      setNotificationsPermission(Notification.permission);
    }
    
    // Reset recurring tasks on component mount
    resetRecurringTasks();
    
    // Set up task filtering based on the active tab
    updateFilteredTasks();
  }, []);
  
  useEffect(() => {
    updateFilteredTasks();
  }, [tasks, activeTab, showCompleted]);
  
  // Schedule notifications for tasks with due times
  useEffect(() => {
    const setupNotifications = () => {
      if (notificationsPermission !== 'granted') return;
      
      // Clear any existing notification timers
      tasks.forEach(task => {
        if (!task.completed && task.dueDate && task.dueTime) {
          const dueDateTime = new Date(`${task.dueDate}T${task.dueTime}`);
          const now = new Date();
          
          // If the due time is in the future, set a notification
          if (dueDateTime > now) {
            const timeUntilDue = dueDateTime.getTime() - now.getTime();
            
            // Set a timer for the notification
            setTimeout(() => {
              new Notification('Task Due', {
                body: `"${task.title}" is due now`,
                icon: '/images/NotificationIcon.jpg'
              });
            }, timeUntilDue);
          }
        }
      });
    };
    
    if (notificationsPermission === 'granted') {
      setupNotifications();
    }
  }, [tasks, notificationsPermission]);
  
  const updateFilteredTasks = () => {
    let filtered: Task[];
    
    if (activeTab === 'today') {
      filtered = getTasksDueToday();
    } else if (activeTab === 'upcoming') {
      filtered = getTasksDueSoon();
    } else {
      filtered = tasks;
    }
    
    // Filter based on completion status if not showing completed
    if (!showCompleted) {
      filtered = filtered.filter(task => !task.completed);
    }
    
    setFilteredTasks(filtered);
  };
  
  const handleDragEnd = (result: DropResult) => {
    const { source, destination } = result;
    
    // Dropped outside the list
    if (!destination) return;
    
    // Reorder tasks
    reorderTasks(source.index, destination.index);
  };
  
  const handleAddTask = (values: any) => {
    const newTask = {
      title: values.title,
      description: values.description || '',
      completed: false,
      dueDate: values.dueDate ? values.dueDate.toISOString().split('T')[0] : null,
      dueTime: values.dueTime || null,
      repeat: values.repeat,
      customDays: values.repeat === 'custom' ? values.customDays : null,
      priority: tasks.length, // Add at the end by default
      lastCompleted: null
    };
    
    addTask(newTask);
    toast.success('Task added successfully!');
  };
  
  const handleUpdateTask = (values: any) => {
    if (!editingTask) return;
    
    const updatedTask = {
      title: values.title,
      description: values.description || '',
      dueDate: values.dueDate ? values.dueDate.toISOString().split('T')[0] : null,
      dueTime: values.dueTime || null,
      repeat: values.repeat,
      customDays: values.repeat === 'custom' ? values.customDays : null,
    };
    
    updateTask(editingTask.id, updatedTask);
    toast.success('Task updated successfully!');
    setEditingTask(null);
  };
  
  const handleFormSubmit = (values: any) => {
    if (editingTask) {
      handleUpdateTask(values);
    } else {
      handleAddTask(values);
    }
  };
  
  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsFormOpen(true);
  };
  
  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      toast.error('This browser does not support notifications');
      return;
    }
    
    try {
      const permission = await Notification.requestPermission();
      setNotificationsPermission(permission);
      
      if (permission === 'granted') {
        toast.success('Notifications enabled');
      } else {
        toast.error('Notification permission denied');
      }
    } catch (error) {
      toast.error('Error requesting notification permission');
    }
  };
  
  return (
    <div className="container mx-auto p-4 max-w-3xl">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Daily To-Do List</h1>
        
        <div className="flex gap-2">
          {notificationsPermission !== 'granted' && (
            <Button 
              variant="outline" 
              size="icon" 
              onClick={requestNotificationPermission}
              title="Enable Notifications"
            >
              <BellIcon className="h-4 w-4" />
            </Button>
          )}
          
          <Button 
            onClick={() => {
              setEditingTask(null);
              setIsFormOpen(true);
            }}
          >
            <PlusIcon className="h-4 w-4 mr-2" /> Add Task
          </Button>
        </div>
      </div>
      
      <TaskForm 
        isOpen={isFormOpen} 
        onClose={() => {
          setIsFormOpen(false);
          setEditingTask(null);
        }}
        onSubmit={handleFormSubmit}
        editingTask={editingTask}
      />
      
      <Tabs 
        defaultValue="today" 
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="today">Today</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="all">All Tasks</TabsTrigger>
          </TabsList>
          
          <div className="flex items-center">
            <label htmlFor="show-completed" className="text-sm mr-2">
              Show Completed
            </label>
            <input
              id="show-completed"
              type="checkbox"
              checked={showCompleted}
              onChange={(e) => setShowCompleted(e.target.checked)}
              className="rounded border-gray-300 text-primary focus:ring-primary"
            />
          </div>
        </div>

        <TabsContent value="today" className="mt-0">
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="today-tasks">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="space-y-4"
                >
                  {filteredTasks.length > 0 ? (
                    filteredTasks.map((task, index) => (
                      <Draggable key={task.id} draggableId={task.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <TaskCard 
                              task={task} 
                              onEdit={handleEditTask} 
                            />
                          </div>
                        )}
                      </Draggable>
                    ))
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      No tasks for today. Click "Add Task" to create one.
                    </div>
                  )}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </TabsContent>
        
        <TabsContent value="upcoming" className="mt-0">
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="upcoming-tasks">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="space-y-4"
                >
                  {filteredTasks.length > 0 ? (
                    filteredTasks.map((task, index) => (
                      <Draggable key={task.id} draggableId={task.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <TaskCard 
                              task={task} 
                              onEdit={handleEditTask} 
                            />
                          </div>
                        )}
                      </Draggable>
                    ))
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      No upcoming tasks.
                    </div>
                  )}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </TabsContent>
        
        <TabsContent value="all" className="mt-0">
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="all-tasks">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="space-y-4"
                >
                  {filteredTasks.length > 0 ? (
                    filteredTasks.map((task, index) => (
                      <Draggable key={task.id} draggableId={task.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <TaskCard 
                              task={task} 
                              onEdit={handleEditTask} 
                            />
                          </div>
                        )}
                      </Draggable>
                    ))
                  ) : (
                    <div className="text-center py-10 text-muted-foreground">
                      No tasks. Click "Add Task" to create one.
                    </div>
                  )}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </TabsContent>
      </Tabs>
    </div>
  );
};