import { useState } from 'react';
import { format } from 'date-fns';
import { CheckIcon, ClockIcon, PencilIcon, TrashIcon } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Task, RepeatType, useTodoStore } from '@/lib/db';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
}

export const TaskCard = ({ task, onEdit }: TaskCardProps) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const { completeTask, deleteTask } = useTodoStore();
  
  const repeatLabels: Record<RepeatType, string> = {
    'none': 'One-time',
    'daily': 'Daily',
    'weekly': 'Weekly',
    'monthly': 'Monthly',
    'custom': 'Custom days'
  };

  const handleComplete = () => {
    completeTask(task.id);
    toast.success(
      task.repeat && task.repeat !== 'none' 
        ? 'Task completed! It will reappear next time it\'s scheduled.' 
        : 'Task completed!'
    );
  };

  const handleDelete = () => {
    if (isDeleting) {
      deleteTask(task.id);
      toast.success('Task deleted');
      setIsDeleting(false);
    } else {
      setIsDeleting(true);
      // Reset after 3 seconds
      setTimeout(() => setIsDeleting(false), 3000);
    }
  };
  
  const getCustomDaysText = () => {
    if (!task.customDays) return '';
    
    const days = [];
    if (task.customDays.monday) days.push('Mon');
    if (task.customDays.tuesday) days.push('Tue');
    if (task.customDays.wednesday) days.push('Wed');
    if (task.customDays.thursday) days.push('Thu');
    if (task.customDays.friday) days.push('Fri');
    if (task.customDays.saturday) days.push('Sat');
    if (task.customDays.sunday) days.push('Sun');
    
    return days.join(', ');
  };
  
  return (
    <Card className={cn(
      "mb-4 transition-all duration-200",
      task.completed && "opacity-70"
    )}>
      <CardHeader className="pb-2 flex flex-row items-start justify-between">
        <div className="flex-1">
          <h3 className={cn(
            "text-lg font-semibold leading-tight flex items-center gap-2",
            task.completed && "line-through text-muted-foreground"
          )}>
            {task.title}
          </h3>
          {task.dueTime && (
            <div className="flex items-center text-sm text-muted-foreground mt-1">
              <ClockIcon size={14} className="mr-1" />
              {task.dueTime}
            </div>
          )}
        </div>
        <div className="flex gap-1">
          {task.repeat && task.repeat !== 'none' && (
            <Badge variant="outline" className="whitespace-nowrap">
              {repeatLabels[task.repeat]} 
              {task.repeat === 'custom' && `: ${getCustomDaysText()}`}
            </Badge>
          )}
          {task.dueDate && (
            <Badge variant="secondary" className="whitespace-nowrap">
              {format(new Date(task.dueDate), 'MMM d')}
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="pb-2">
        {task.description && (
          <p className={cn(
            "text-sm text-muted-foreground",
            task.completed && "line-through"
          )}>
            {task.description}
          </p>
        )}
      </CardContent>
      
      <CardFooter className="pt-0 flex justify-end gap-2">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onEdit(task)}
        >
          <PencilIcon size={14} className="mr-1" /> Edit
        </Button>
        
        <Button 
          variant="outline" 
          size="sm" 
          className={isDeleting ? "bg-destructive text-destructive-foreground hover:bg-destructive/90" : ""}
          onClick={handleDelete}
        >
          <TrashIcon size={14} className="mr-1" />
          {isDeleting ? "Confirm" : "Delete"}
        </Button>
        
        {!task.completed && (
          <Button 
            variant="default" 
            size="sm"
            onClick={handleComplete}
          >
            <CheckIcon size={14} className="mr-1" /> Complete
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};