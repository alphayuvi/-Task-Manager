import { useEffect } from 'react';
import { TaskList } from '@/components/task-list';
import { ThemeToggle } from '@/components/theme-toggle';

export default function TodoApp() {
  // Initialize theme on page load
  useEffect(() => {
    const theme = localStorage.getItem("theme") as "light" | "dark" | "system" || "system";
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");

    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light";
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme);
    }
  }, []);

  return (
    <div className="min-h-screen bg-background transition-all">
      <header className="border-b">
        <div className="container flex items-center justify-between p-4 max-w-3xl mx-auto">
          <h1 className="text-xl font-bold">Daily To-Do List</h1>
          <ThemeToggle />
        </div>
      </header>

      <main className="pt-4">
        <TaskList />
      </main>

      <footer className="mt-20 py-6 border-t">
        <div className="container text-center text-sm text-muted-foreground max-w-3xl mx-auto">
          <p>Daily To-Do List App &copy; {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
}